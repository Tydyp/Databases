from pymongo import MongoClient
from bson.objectid import ObjectId
from pprint import pprint

createData = {}
searchTarget = {}
updateTarget = {}
newUpdateTarget = {}
deleteTarget = {}

class AnimalShelter(object):

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to
        # access the MongoDB databases and collections.
        self.client = MongoClient('mongodb://%s:%s@localhost:54370/AAC' % (username, password))
        self.database = self.client['AAC']
        
# Method to obtain create data from user.
    def obtainCreateData(self):
        values = ['1', 'age_upon_outcome','animal_type', 'breed', 'color', 'date_of_birth','datetime',
                  'monthyear','name','outcome_subtype', 'outcome_type', 'sex_upon_outcome','location_lat',
                  'location_long', 'age_upon_outcome_in_weeks']
        for i in range (len(values)):
            key = values[i]
            value = input("Enter " + values[i] + ": ")
            createData.update({key: value})

# Method to implement the C in CRUD.
    def create(self,data):
       if data is not None:
            animalInsert = self.database.animals.insert_one(data) #data should be dictionary
            print(animalInsert)
            return True
       else:
            raise Exception("Nothing to save, because data target is empty")
 
 #Get target data for R.
    def getReadData(self):
        for i in range(1):
            key = input("Enter search key: ")
            value = input("Enter search value: ")
            searchTarget.update({key: value})


 # Method to implement the R in CRUD
    def read(self, target):
     # In order to find data matching the search.
        if target is not None:
            readResult = list(self.database.animals.find(target, {"_id": False}))
            return readResult
        else:
            raise Exception("Nothing to search, the target is empty")
            return False
        
 # Method to get target data for U.
    def getUpdateData(self):
        for i in range(1):
            key = input("Enter update key: ")
            value = input("Enter update value: ")
            updateTarget.update({key: value})
            #Obatain new value that user wants to update to.
        for i in range(1):
            key = input("Enter update key: ")
            value = input("Enter new update value: ")
            newUpdateTarget.update({'$set': {key: value}})
        print(newUpdateTaraget)
            
   
 # Method to implement the U in CRUD
    def update(self, updateTarget, newUpdateTarget, count):
        if updateTarget is not None:
            if count == 1:
                updateResult = self.database.animals.update_one(updateTarget, newUpdateTarget)
                print("Matched Count: " + str(updateResult.matched_count) + ", Modified Count: " + str(updateResult.modified_count))
                if updateResult.modified_count ==1:
                    print("Success")
                    print(updateResult)
                    return True
                else:
                    print("Something went wrong")
                    return False
            elif count == 2:
                updateResult = self.database.animals.update_many(updateTarget, newUpdateTarget)
                print("Matched Count: " + str(updateResult.matched_count) + ", Modified Count: " + str(updateResult.modified_count))
                if updateResult.modified_count == updateResult.matched_count:
                    print("Success")
                    print(updateResult)
                    return True
                else:
                    print("Something went wrong, all items may not have been updated.")
                    print(updateResult)
                    return True
            else:
                print("Could not recognize, please try again.")
                return False
        else:
            raise Exception("Nothing to update, at least one target is empty.")
            return False
 
 # Method to get target data for D.
    def getDeleteData(self):
        for i in range(1):
            key = input("Enter delete key: ")
            value = input("Enter delete value: ")
            deleteTarget.update({key: value})
    
 # Method to implement the D in CRUD
    def delete(self, delete, count):
         if delete is not None:
                if count == 1:
                    try:
                        deleteResult = self.database.animals.delete_one(delete)
                        print("Deleted count: " + str(deleteResult.deleted_count))
                        if deleteResult.deleted_count == 0:
                            print("Nothing to be deleted.")
                            print(deleteResult)
                            return True
                        else:
                            print("Success")
                            print(deleteResult)
                            return True
                    except Exception as e:
                        print("An exception has occurred: ", e)
                elif count ==2:
                    try:
                        deleteResult = self.database.animals.delete_many(delete)
                        print("Deleted count: " + str(deleteResult.deleted_count))
                        if deleteResult.deleted_count == 0:
                            print("Nothing to be deleted.")
                            print(deleteResult)
                            return True
                        else:
                            print("Success")
                            print(deleteResult)
                            return True
                    except Exception as e:
                        print("An exception has occurred: ", e)
                        return False
                else:
                    raise Exception("Nothing to delete, target is empty.")
                    return False
                            
      
          